import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:tianyuansenquan_app/main.dart';

void main() {
  testWidgets('首页展示品牌、售价和购物车导航', (tester) async {
    await tester.pumpWidget(const TianyuanApp());
    expect(find.text('天源森泉'), findsWidgets);
    expect(find.text('¥72'), findsOneWidget);
    expect(find.text('购物车'), findsOneWidget);
    expect(find.byIcon(Icons.home), findsWidgets);
  });
}
