import 'package:flutter_test/flutter_test.dart';
import 'package:tianyuansenquan_app/shop.dart';

void main() {
  test('单价与购物车合计', () {
    final shop = ShopState();
    shop.addToCart(2);
    expect(shop.cartQuantity, 2);
    expect(shop.cartTotal, 144);
    shop.changeCartQuantity(3);
    expect(shop.cartTotal, 216);
    shop.changeCartQuantity(-5);
    expect(shop.cartQuantity, 0);
  });

  test('校验信息、建立未付款模拟订单并清空购物车', () {
    final shop = ShopState()..addToCart(2);
    expect(shop.placeDemoOrder(deliveryMethod: DeliveryMethod.local,
      address: const ShippingAddress(name: '', phone: '', detail: '')), isNull);
    expect(shop.cartQuantity, 2);
    final order = shop.placeDemoOrder(deliveryMethod: DeliveryMethod.nationwide,
      address: const ShippingAddress(name: '测试用户', phone: '13800000000', detail: '测试地址'));
    expect(order, isNotNull);
    expect(order!.total, 144);
    expect(shop.cartQuantity, 0);
    expect(shop.orders.length, 1);
  });
}
