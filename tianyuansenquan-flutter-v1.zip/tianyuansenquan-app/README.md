# 天源森泉 · 520ml 矿泉水商城（Flutter v1）

本仓库提供 **Android 与 iOS 共用的 Flutter 商城演示源码**。目前为本地内存演示：没有后台、用户账号、订单上传或真实付款。关闭 APP 后购物车和模拟订单将清空。

## 功能

- 视觉主题：深森林绿、浅薄荷绿、香槟金；品牌瓶身为 **Flutter 绘制的示意图，不是实物照片**。
- 首页、商品详情、购物车、确认订单、订单列表、个人中心。
- 520ml × 24 瓶/箱，人民币 72 元/箱；加减数量、自动汇总。
- 全国快递 / 同城配送选择；填写姓名、联系电话、详细地址。
- 仅生成本地 `DEMO-...` 订单，状态始终为 **未付款**。运费暂按 0 展示，仅是演示占位，不代表正式报价。
- `lib/shop.dart` 提供 `WeChatAuthGateway`、`PaymentGateway` 接口声明，但**没有微信登录、微信支付、支付宝支付的实现**。不存在真实扣款。

## 开发环境

Flutter stable（建议 Flutter 3.24 或更新版本）、Dart 3.3+；Android 构建需 Android SDK，iOS 构建必须在 macOS 安装 Xcode。运行 `flutter doctor` 解决环境问题。

## 安装 / 运行

```bash
git clone https://github.com/ly19239286561-create/tianyuansenquan-app.git
cd tianyuansenquan-app
# 首次生成 Android/iOS 原生工程及平台配置：
flutter create --platforms=android,ios --project-name=tianyuansenquan_app --org=com.tianyuansenquan .
flutter pub get
flutter run
```

注意：**当前离线源码包不含 Flutter SDK 自动生成的 android/ 和 ios/ 原生目录**。必须执行上述 `flutter create` 才能生成完整 Android Gradle 与 iOS Xcode 配置。如果仓库要求直接包含原生目录，请先在有 SDK 的环境运行此命令，再提交生成的目录。Android 包名 / iOS Bundle ID 基于 `com.tianyuansenquan.tianyuansenquan_app`，正式发布前请核定。

## 检查和构建

```bash
flutter analyze
flutter test
flutter build apk --release
flutter build appbundle --release
# 仅 macOS + Xcode：
flutter build ios --release
```

正式发行需另行配置 Android 签名密钥、iOS Team/证书和 App Store 相关信息。

## 集成计划（未开通）

1. 增加服务器订单、用户、地址和运费规则，**在后端重新计算价格**。
2. 微信登录：申请移动应用资质/开放平台 AppID 并配置签名、回调及后端会话。
3. 支付：分别完成微信商户号/支付宝开放平台申请；由后端创建支付单、验证签名和异步回调，支付状态只由可信服务器修改。
4. 增加真实商品图片、库存、地址管理、订单持久化及隐私政策。

## 验证状态

开发此演示源码的环境 **未安装 Flutter/Dart SDK**，因此未实际执行 `flutter analyze`、`flutter test` 或生成 APK/IPA。仓库 CI 文件 `.github/workflows/flutter.yml` 会在启用 GitHub Actions 后尝试运行静态分析、测试和 debug APK 构建；**CI 通过前不得将结果视为已验证**。
