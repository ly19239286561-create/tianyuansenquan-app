#!/usr/bin/env bash
set -euo pipefail
# Run once with an installed Flutter SDK to generate/update native Android and iOS projects.
flutter create --platforms=android,ios --project-name=tianyuansenquan_app --org=com.tianyuansenquan .
flutter pub get
flutter analyze
flutter test
