import 'package:flutter/foundation.dart';

const int pricePerCase = 72;
const String productTitle = '天源森泉 · 520ml 天然饮用水';

enum DeliveryMethod { nationwide, local }

extension DeliveryName on DeliveryMethod {
  String get label => this == DeliveryMethod.nationwide ? '全国快递' : '同城配送';
}

@immutable
class ShippingAddress {
  const ShippingAddress({required this.name, required this.phone, required this.detail});
  final String name;
  final String phone;
  final String detail;
}

@immutable
class DemoOrder {
  const DemoOrder({required this.id, required this.createdAt, required this.quantity,
    required this.deliveryMethod, required this.address});
  final String id;
  final DateTime createdAt;
  final int quantity;
  final DeliveryMethod deliveryMethod;
  final ShippingAddress address;
  int get total => quantity * pricePerCase;
}

/// Local demonstration state. No network calls, accounts, or payments.
class ShopState extends ChangeNotifier {
  int _cartQuantity = 0;
  final List<DemoOrder> _orders = [];
  int get cartQuantity => _cartQuantity;
  int get cartTotal => _cartQuantity * pricePerCase;
  List<DemoOrder> get orders => List.unmodifiable(_orders);

  void addToCart([int amount = 1]) {
    if (amount <= 0) return;
    _cartQuantity += amount;
    notifyListeners();
  }

  void changeCartQuantity(int value) {
    _cartQuantity = value < 0 ? 0 : value;
    notifyListeners();
  }

  DemoOrder? placeDemoOrder({required DeliveryMethod deliveryMethod,
      required ShippingAddress address}) {
    if (_cartQuantity < 1 || address.name.trim().isEmpty ||
        address.phone.trim().isEmpty || address.detail.trim().isEmpty) {
      return null;
    }
    final now = DateTime.now();
    final order = DemoOrder(
      id: 'DEMO-${now.microsecondsSinceEpoch}', createdAt: now,
      quantity: _cartQuantity, deliveryMethod: deliveryMethod, address: address,
    );
    _orders.insert(0, order);
    _cartQuantity = 0;
    notifyListeners();
    return order;
  }
}

/// Explicit integration contracts, intentionally unimplemented in version 1.
abstract interface class WeChatAuthGateway {
  Future<void> signIn();
}

abstract interface class PaymentGateway {
  Future<void> payWithWeChat(DemoOrder order);
  Future<void> payWithAlipay(DemoOrder order);
}
