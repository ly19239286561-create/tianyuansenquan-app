import 'package:flutter/material.dart';
import 'shop.dart';

void main() => runApp(const TianyuanApp());

const forest = Color(0xFF173C32);
const mint = Color(0xFFE8F1EB);
const gold = Color(0xFFB28D51);

class TianyuanApp extends StatefulWidget {
  const TianyuanApp({super.key});
  @override
  State<TianyuanApp> createState() => _TianyuanAppState();
}

class _TianyuanAppState extends State<TianyuanApp> {
  final ShopState shop = ShopState();
  @override
  void dispose() { shop.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: '天源森泉', debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true, scaffoldBackgroundColor: const Color(0xFFF8FAF7),
      colorScheme: ColorScheme.fromSeed(seedColor: forest, primary: forest),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF8FAF7),
          foregroundColor: forest, centerTitle: true),
      filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(50), shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14)))),
    ),
    home: StoreShell(shop: shop),
  );
}

class StoreShell extends StatefulWidget {
  const StoreShell({super.key, required this.shop});
  final ShopState shop;
  @override
  State<StoreShell> createState() => _StoreShellState();
}

class _StoreShellState extends State<StoreShell> {
  int selected = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [HomePage(shop: widget.shop), CartPage(shop: widget.shop),
      OrdersPage(shop: widget.shop), ProfilePage(shop: widget.shop)];
    return AnimatedBuilder(animation: widget.shop, builder: (context, _) => Scaffold(
      body: SafeArea(child: IndexedStack(index: selected, children: pages)),
      bottomNavigationBar: NavigationBar(selectedIndex: selected, onDestinationSelected: (v) =>
          setState(() => selected = v), destinations: [
        const NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: '首页'),
        NavigationDestination(icon: Badge(isLabelVisible: widget.shop.cartQuantity > 0,
          label: Text('${widget.shop.cartQuantity}'), child: const Icon(Icons.shopping_bag_outlined)), label: '购物车'),
        const NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: '订单'),
        const NavigationDestination(icon: Icon(Icons.person_outline), label: '我的'),
      ]),
    ));
  }
}

class WaterArt extends StatelessWidget {
  const WaterArt({super.key, this.height = 245});
  final double height;
  @override
  Widget build(BuildContext context) => Container(
    height: height, width: double.infinity,
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(24),
      gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
      colors: [Color(0xFFDCEFE7), Color(0xFFB5D1C5)])),
    child: Stack(alignment: Alignment.center, children: [
      Positioned(top: 20, left: 22, child: Text('来自自然 · 清澈每一天',
        style: TextStyle(color: forest.withValues(alpha: .75), letterSpacing: 2))),
      Container(width: 90, height: height * .72,
        decoration: BoxDecoration(color: const Color(0xFFEEF9F8).withValues(alpha: .78),
          borderRadius: BorderRadius.circular(28), border: Border.all(color: Colors.white, width: 3),
          boxShadow: const [BoxShadow(color: Color(0x22002119), blurRadius: 22, offset: Offset(8, 8))]),
        child: Column(children: [
          Container(width: 46, height: 16, decoration: const BoxDecoration(color: forest,
              borderRadius: BorderRadius.vertical(top: Radius.circular(6)))),
          const Spacer(),
          Container(width: double.infinity, padding: const EdgeInsets.symmetric(vertical: 12),
            color: forest, child: const Column(children: [Text('天源森泉',
                style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 15)),
              Text('TIANYUAN', style: TextStyle(color: Color(0xFFE1C99C), fontSize: 9))])),
          const Spacer(),
          const Text('520mL', style: TextStyle(color: forest, fontSize: 12)),
          const SizedBox(height: 12),
        ])),
      const Positioned(bottom: 15, right: 22, child: Text('24瓶 / 箱',
          style: TextStyle(color: forest, fontWeight: FontWeight.w600))),
    ]),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key, required this.shop});
  final ShopState shop;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(22), children: [
    const SizedBox(height: 14),
    const Text('天源森泉', style: TextStyle(fontSize: 34, color: forest,
        fontWeight: FontWeight.w700, letterSpacing: 4)),
    const Text('TIANYUAN SENQUAN  /  品质好水',
        style: TextStyle(color: gold, letterSpacing: 1.5, fontSize: 11)),
    const SizedBox(height: 26),
    const WaterArt(height: 280),
    const SizedBox(height: 23),
    const Text('把自然的清澈，送到你身边',
        style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: forest)),
    const SizedBox(height: 9),
    const Text('520ml × 24瓶 / 箱  ·  全国快递 / 同城配送'),
    const SizedBox(height: 22),
    Row(children: [const Text('¥72', style: TextStyle(fontSize: 31, color: forest,
        fontWeight: FontWeight.bold)), const Text(' / 箱'), const Spacer(),
      FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(
        builder: (_) => ProductPage(shop: shop))), child: const Text('查看详情  →'))]),
    const SizedBox(height: 32),
    const Center(child: Text('自然本味  ·  简单生活', style: TextStyle(color: gold, letterSpacing: 3))),
  ]);
}

class QuantityControl extends StatelessWidget {
  const QuantityControl({super.key, required this.value, required this.onChanged});
  final int value;
  final ValueChanged<int> onChanged;
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
    IconButton(onPressed: value > 1 ? () => onChanged(value - 1) : null,
        icon: const Icon(Icons.remove_circle_outline)),
    Text('$value', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
    IconButton(onPressed: () => onChanged(value + 1), icon: const Icon(Icons.add_circle_outline)),
  ]);
}

class ProductPage extends StatefulWidget {
  const ProductPage({super.key, required this.shop});
  final ShopState shop;
  @override
  State<ProductPage> createState() => _ProductPageState();
}
class _ProductPageState extends State<ProductPage> {
  int quantity = 1;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('商品详情')),
    body: ListView(padding: const EdgeInsets.all(22), children: [
      const WaterArt(height: 310), const SizedBox(height: 20),
      const Text(productTitle, style: TextStyle(fontSize: 23, color: forest,
          fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      const Text('规格：520ml / 瓶 · 24瓶 / 箱'),
      const SizedBox(height: 8),
      const Text('支持全国快递与同城配送，实际配送费用暂未接入。'),
      const SizedBox(height: 15),
      const Text('¥72 / 箱', style: TextStyle(fontSize: 27, color: forest,
          fontWeight: FontWeight.bold)),
      Row(children: [const Text('购买数量'), const Spacer(),
        QuantityControl(value: quantity, onChanged: (v) => setState(() => quantity = v))]),
    ]),
    bottomNavigationBar: SafeArea(minimum: const EdgeInsets.all(16), child:
      FilledButton(onPressed: () {widget.shop.addToCart(quantity);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已加入购物车')));
      }, child: Text('加入购物车  ¥${quantity * pricePerCase}'))),
  );
}

class CartPage extends StatelessWidget {
  const CartPage({super.key, required this.shop});
  final ShopState shop;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('购物车')),
    body: AnimatedBuilder(animation: shop, builder: (_, _) => shop.cartQuantity == 0
      ? const Center(child: Text('购物车还是空的，去首页挑选好水吧'))
      : ListView(padding: const EdgeInsets.all(20), children: [
        const WaterArt(height: 175), const SizedBox(height: 17),
        const Text(productTitle, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6), const Text('24瓶/箱   ¥72/箱'),
        Row(children: [const Text('数量'), const Spacer(),
          QuantityControl(value: shop.cartQuantity, onChanged: shop.changeCartQuantity),
          IconButton(tooltip: '清空购物车', onPressed: () => shop.changeCartQuantity(0),
              icon: const Icon(Icons.delete_outline))]),
        const Divider(),
        Align(alignment: Alignment.centerRight, child: Text('商品合计：¥${shop.cartTotal}',
            style: const TextStyle(fontSize: 20, color: forest, fontWeight: FontWeight.bold))),
      ])),
    bottomNavigationBar: AnimatedBuilder(animation: shop, builder: (context, _) =>
      shop.cartQuantity == 0 ? const SizedBox.shrink() : SafeArea(
        minimum: const EdgeInsets.all(16), child: FilledButton(
          onPressed: () => Navigator.push(context, MaterialPageRoute(
            builder: (_) => CheckoutPage(shop: shop))), child: Text('去结算  ¥${shop.cartTotal}')))),
  );
}

class CheckoutPage extends StatefulWidget {
  const CheckoutPage({super.key, required this.shop});
  final ShopState shop;
  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}
class _CheckoutPageState extends State<CheckoutPage> {
  final key = GlobalKey<FormState>();
  final name = TextEditingController();
  final phone = TextEditingController();
  final address = TextEditingController();
  DeliveryMethod method = DeliveryMethod.nationwide;
  @override
  void dispose() { name.dispose(); phone.dispose(); address.dispose(); super.dispose(); }
  Widget field(TextEditingController controller, String label, {TextInputType? type}) =>
    Padding(padding: const EdgeInsets.only(bottom: 14), child: TextFormField(
      controller: controller, keyboardType: type,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      validator: (value) => value == null || value.trim().isEmpty ? '请填写$label' : null,
    ));
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('确认订单')),
    body: Form(key: key, child: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('配送方式', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      RadioListTile<DeliveryMethod>(title: const Text('全国快递'), value: DeliveryMethod.nationwide,
          groupValue: method, onChanged: (value) => setState(() => method = value!)),
      RadioListTile<DeliveryMethod>(title: const Text('同城配送'), value: DeliveryMethod.local,
          groupValue: method, onChanged: (value) => setState(() => method = value!)),
      const SizedBox(height: 12),
      const Text('收货信息', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 16),
      field(name, '收货人'), field(phone, '联系电话', type: TextInputType.phone),
      field(address, '详细收货地址'),
      const Divider(height: 35),
      Text('商品数量：${widget.shop.cartQuantity} 箱'),
      const SizedBox(height: 8),
      Text('商品金额：¥${widget.shop.cartTotal}', style: const TextStyle(
          fontSize: 19, fontWeight: FontWeight.bold, color: forest)),
      const SizedBox(height: 8),
      const Text('演示版运费暂记为 ¥0；该金额不是正式运费报价。',
          style: TextStyle(color: Colors.deepOrange)),
      const SizedBox(height: 8),
      const Text('微信支付、支付宝支付未开通；不会扣款或生成真实交易。',
          style: TextStyle(color: Colors.deepOrange)),
    ])),
    bottomNavigationBar: SafeArea(minimum: const EdgeInsets.all(16), child: FilledButton(
      onPressed: () {
        if (!key.currentState!.validate()) return;
        final order = widget.shop.placeDemoOrder(deliveryMethod: method,
          address: ShippingAddress(name: name.text, phone: phone.text, detail: address.text));
        if (order == null) return;
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) =>
          DemoOrderResultPage(order: order)));
      }, child: Text('创建模拟订单  ¥${widget.shop.cartTotal}'))),
  );
}

class DemoOrderResultPage extends StatelessWidget {
  const DemoOrderResultPage({super.key, required this.order});
  final DemoOrder order;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('模拟订单已创建')),
    body: Padding(padding: const EdgeInsets.all(28), child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Icon(Icons.check_circle_outline, size: 76, color: forest),
      const SizedBox(height: 22),
      const Center(child: Text('模拟订单创建成功', style: TextStyle(fontSize: 23,
          fontWeight: FontWeight.bold, color: forest))),
      const SizedBox(height: 14),
      const Text('仅用于界面演示，未支付、未发货，不代表商家已收到订单。', textAlign: TextAlign.center),
      const SizedBox(height: 24),
      Text('演示单号：${order.id}'),
      Text('商品合计：¥${order.total}'),
      Text('配送方式：${order.deliveryMethod.label}'),
      const Spacer(),
      FilledButton(onPressed: () => Navigator.pop(context), child: const Text('返回商城')),
    ])),
  );
}

class OrdersPage extends StatelessWidget {
  const OrdersPage({super.key, required this.shop});
  final ShopState shop;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('我的订单')),
    body: AnimatedBuilder(animation: shop, builder: (_, _) => shop.orders.isEmpty
      ? const Center(child: Text('暂无模拟订单'))
      : ListView.builder(padding: const EdgeInsets.all(16), itemCount: shop.orders.length,
          itemBuilder: (_, index) {
        final order = shop.orders[index];
        return Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(
          padding: const EdgeInsets.all(16), child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [const Expanded(child: Text('天源森泉 · 520ml',
                style: TextStyle(fontWeight: FontWeight.bold))),
              Text('¥${order.total}', style: const TextStyle(color: forest,
                  fontWeight: FontWeight.bold))]),
            const SizedBox(height: 8),
            Text('${order.quantity}箱 · ${order.deliveryMethod.label}'),
            Text('收件人：${order.address.name}'),
            Text('地址：${order.address.detail}'),
            const SizedBox(height: 6),
            const Text('状态：本地模拟订单 / 未付款', style: TextStyle(color: Colors.deepOrange)),
            Text('编号：${order.id}', style: const TextStyle(fontSize: 11)),
          ])));
      })),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key, required this.shop});
  final ShopState shop;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('个人中心')),
    body: ListView(padding: const EdgeInsets.all(22), children: [
      const SizedBox(height: 20),
      const CircleAvatar(radius: 38, backgroundColor: mint,
          child: Icon(Icons.person_outline, size: 40, color: forest)),
      const SizedBox(height: 16),
      const Center(child: Text('游客体验模式', style: TextStyle(fontSize: 23,
          fontWeight: FontWeight.bold, color: forest))),
      const SizedBox(height: 7),
      const Center(child: Text('登录与会员功能暂未开通')),
      const SizedBox(height: 35),
      Card(child: ListTile(leading: const Icon(Icons.chat_outlined),
        title: const Text('微信登录'), subtitle: const Text('未开通 · 待接入官方SDK'),
        trailing: const Icon(Icons.lock_outline),
        onTap: () => ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('微信登录暂未开通'))))),
      const Card(child: ListTile(leading: Icon(Icons.payment_outlined),
        title: Text('支付功能'), subtitle: Text('微信支付 / 支付宝支付均未开通'),
        trailing: Icon(Icons.lock_outline))),
      const Card(child: ListTile(leading: Icon(Icons.info_outline),
        title: Text('版本信息'), subtitle: Text('v1.0 本地演示版 · 无真实交易'))),
    ]),
  );
}
